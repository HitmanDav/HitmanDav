import asyncio
import logging
from aiogram.types import BufferedInputFile
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram import F
import openai
from datetime import datetime
from typing import Dict, List
from io import BytesIO
import sqlite3
import aiohttp
import yaml
from collections import defaultdict
import matplotlib.pyplot as plt
import seaborn as sns

# Настройка токенов и путей
TELEGRAM_TOKEN = "7901663076:AAGOm0Z8qaDIG7xfAsHmk38T8duPA_bbwjo"
OPENAI_TOKEN = "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"
WEATHER_API_KEY = "643d5ae46f106ea1806637ac8130769f"

# Инициализация бота и OpenAI
bot = Bot(token=TELEGRAM_TOKEN)
dp = Dispatcher()
openai.api_key = OPENAI_TOKEN

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# Инициализация SQLite
def init_db():
    conn = sqlite3.connect("bot_settings.db")
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS user_settings
                 (user_id INTEGER PRIMARY KEY, model TEXT, temp REAL, max_tokens INTEGER, language TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS analytics
                 (user_id INTEGER, command TEXT, timestamp TEXT)''')
    conn.commit()
    conn.close()


init_db()

# Загрузка переводов
with open("translations.yaml", "r", encoding="utf-8") as f:
    TRANSLATIONS = yaml.safe_load(f)

# Словарь для хранения истории чата
chat_history: Dict[int, List[Dict[str, str]]] = {}

# Параметры по умолчанию
DEFAULT_MODEL = "gpt-3.5-turbo"
DEFAULT_TEMP = 0.7
DEFAULT_MAX_TOKENS = 500
DEFAULT_LANGUAGE = "ru"

# Аналитика
analytics_data = defaultdict(int)


# Функция для получения настроек пользователя
def get_user_settings(user_id: int) -> Dict:
    conn = sqlite3.connect("bot_settings.db")
    c = conn.cursor()
    c.execute("SELECT model, temp, max_tokens, language FROM user_settings WHERE user_id = ?", (user_id,))
    result = c.fetchone()
    conn.close()
    if result:
        return {
            "model": result[0],
            "temp": result[1],
            "max_tokens": result[2],
            "language": result[3]
        }
    return {
        "model": DEFAULT_MODEL,
        "temp": DEFAULT_TEMP,
        "max_tokens": DEFAULT_MAX_TOKENS,
        "language": DEFAULT_LANGUAGE
    }


# Функция для сохранения настроек пользователя
def save_user_settings(user_id: int, settings: Dict):
    conn = sqlite3.connect("bot_settings.db")
    c = conn.cursor()
    c.execute('''INSERT OR REPLACE INTO user_settings (user_id, model, temp, max_tokens, language)
                 VALUES (?, ?, ?, ?, ?)''',
              (user_id, settings["model"], settings["temp"], settings["max_tokens"], settings["language"]))
    conn.commit()
    conn.close()


@dp.message(Command("start"))
async def send_welcome(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/start")

    # Create keyboard buttons first
    btn1 = types.KeyboardButton(text=get_translation(user_id, "info_button"))
    btn2 = types.KeyboardButton(text=get_translation(user_id, "settings_button"))
    btn3 = types.KeyboardButton(text=get_translation(user_id, "history_button"))
    btn4 = types.KeyboardButton(text=get_translation(user_id, "language_button"))

    # Create the keyboard markup with the buttons
    markup = types.ReplyKeyboardMarkup(
        keyboard=[
            [btn1, btn2],  # First row with 2 buttons
            [btn3, btn4]  # Second row with 2 buttons
        ],
        resize_keyboard=True
    )

    await message.reply(
        get_translation(user_id, "welcome_message"),
        reply_markup=markup
    )


@dp.message(Command("analytics"))
async def show_analytics(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/analytics")

    stats = "\n".join([f"{cmd}: {count}" for cmd, count in analytics_data.items()])
    plot = create_analytics_plot()

    # Конвертируем BytesIO в BufferedInputFile
    photo = BufferedInputFile(
        file=plot.getvalue(),
        filename="analytics.png"
    )

    await message.reply(get_translation(user_id, "analytics_message").format(stats))
    await message.reply_photo(
        photo=photo,
        caption=get_translation(user_id, "analytics_plot_caption")
    )

@dp.message(Command("settings"))
async def show_settings(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/settings")

    # Создаем кнопки
    btn1 = types.InlineKeyboardButton(
        text=get_translation(user_id, "model_button"),
        callback_data="set_model"
    )
    btn2 = types.InlineKeyboardButton(
        text=get_translation(user_id, "temp_button"),
        callback_data="set_temp"
    )
    btn3 = types.InlineKeyboardButton(
        text=get_translation(user_id, "tokens_button"),
        callback_data="set_tokens"
    )

    # Создаем разметку с кнопками
    markup = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [btn1],  # Первая строка с одной кнопкой
            [btn2],  # Вторая строка с одной кнопкой
            [btn3]  # Третья строка с одной кнопкой
        ]
    )

    await message.reply(
        get_translation(user_id, "select_setting"),
        reply_markup=markup
    )

# Функция для логирования аналитики
def log_analytics(user_id: int, command: str):
    conn = sqlite3.connect("bot_settings.db")
    c = conn.cursor()
    c.execute("INSERT INTO analytics (user_id, command, timestamp) VALUES (?, ?, ?)",
              (user_id, command, datetime.now().isoformat()))
    conn.commit()
    conn.close()
    analytics_data[command] += 1


# Функция для получения перевода
def get_translation(user_id: int, key: str) -> str:
    settings = get_user_settings(user_id)
    lang = settings["language"]
    return TRANSLATIONS.get(lang, {}).get(key, TRANSLATIONS["ru"][key])


@dp.message(F.text)
async def handle_message(message: types.Message):
    user_id = message.from_user.id
    user_text = message.text

    log_analytics(user_id, "text_message")

    translations = {
        get_translation(user_id, "info_button"): lambda: message.reply(get_translation(user_id, "info_message")),
        get_translation(user_id, "settings_button"): show_settings,
        get_translation(user_id, "history_button"): lambda: message.reply(
            "\n".join([f"{msg['role']}: {msg['content']}" for msg in chat_history.get(user_id, [])])
            if user_id in chat_history and chat_history[user_id]
            else get_translation(user_id, "history_empty")
        ),
        get_translation(user_id, "language_button"): lambda: message.reply(
            get_translation(user_id, "language_prompt"),
            reply_markup=types.InlineKeyboardMarkup(
                inline_keyboard=[
                    [types.InlineKeyboardButton(text=lang, callback_data=f"lang_{lang}")]
                    for lang in TRANSLATIONS.keys()
                ]
            )
        )
    }

    if user_text in translations:
        await translations[user_text]()
    else:
        response = await get_openai_response(user_id, user_text)
        await message.reply(response)

# Функция для создания графика аналитики
def create_analytics_plot():
    plt.figure(figsize=(10, 6))
    sns.barplot(x=list(analytics_data.values()), y=list(analytics_data.keys()))
    plt.title("Command Usage Statistics")
    plt.xlabel("Count")
    plt.ylabel("Command")
    buf = BytesIO()
    plt.savefig(buf, format="png")
    plt.close()
    buf.seek(0)
    return buf


# Функция для отправки запроса к OpenAI
async def get_openai_response(user_id: int, message: str) -> str:
    settings = get_user_settings(user_id)
    try:
        user_history = chat_history.get(user_id, [])
        user_history.append({"role": "user", "content": message})
        if len(user_history) > 10:
            user_history = user_history[-10:]

        messages = [{"role": "system", "content": get_translation(user_id, "system_prompt")}] + user_history

        response = await openai.ChatCompletion.acreate(
            model=settings["model"],
            messages=messages,
            temperature=settings["temp"],
            max_tokens=settings["max_tokens"]
        )

        assistant_response = response.choices[0].message['content']
        user_history.append({"role": "assistant", "content": assistant_response})
        chat_history[user_id] = user_history

        return assistant_response
    except Exception as e:
        logger.error(f"Ошибка OpenAI API: {str(e)}")
        return get_translation(user_id, "error_openai")


# Функция для генерации аудио
async def generate_audio(user_id: int, text: str) -> BytesIO:
    try:
        response = await openai.Audio.acreate(
            model="tts-1",
            voice="alloy",
            input=text
        )
        audio_data = response['data']
        return BytesIO(audio_data)
    except Exception as e:
        logger.error(f"Ошибка генерации аудио: {str(e)}")
        return None


# Функция для распознавания речи
async def recognize_speech(audio_file: BytesIO) -> str:
    try:
        response = await openai.Audio.transcribe(
            model="whisper-1",
            file=audio_file
        )
        return response['text']
    except Exception as e:
        logger.error(f"Ошибка распознавания речи: {str(e)}")
        return "Не удалось распознать речь."


# Функция для генерации изображений
async def generate_image(user_id: int, prompt: str) -> str:
    try:
        response = await openai.Image.acreate(
            model="dall-e-3",
            prompt=prompt,
            n=1,
            size="1024x1024"
        )
        return response['data'][0]['url']
    except Exception as e:
        logger.error(f"Ошибка генерации изображения: {str(e)}")
        return None


# Функция для анализа видео
async def analyze_video(user_id: int, video_url: str) -> str:
    try:
        response = await openai.ChatCompletion.acreate(
            model="gpt-4-vision-preview",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Опиши содержимое этого видео."},
                        {"type": "video_url", "video_url": video_url}
                    ]
                }
            ],
            max_tokens=300
        )
        return response.choices[0].message['content']
    except Exception as e:
        logger.error(f"Ошибка анализа видео: {str(e)}")
        return get_translation(user_id, "video_error")


# Функция для получения погоды
async def get_weather(user_id: int, city: str) -> str:
    async with aiohttp.ClientSession() as session:
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={WEATHER_API_KEY}&units=metric&lang={get_user_settings(user_id)['language']}"
        async with session.get(url) as response:
            if response.status == 200:
                data = await response.json()
                return get_translation(user_id, "weather_message").format(
                    city=data["name"],
                    temp=data["main"]["temp"],
                    description=data["weather"][0]["description"]
                )
            else:
                return get_translation(user_id, "weather_error")


# Обработчик команды /start
@dp.message(Command("start"))
async def send_welcome(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/start")

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton(get_translation(user_id, "info_button"))
    btn2 = types.KeyboardButton(get_translation(user_id, "settings_button"))
    btn3 = types.KeyboardButton(get_translation(user_id, "history_button"))
    btn4 = types.KeyboardButton(get_translation(user_id, "language_button"))
    markup.add(btn1, btn2, btn3, btn4)

    await message.reply(
        get_translation(user_id, "welcome_message"),
        reply_markup=markup
    )


# Обработчик команды /clear
@dp.message(Command("clear"))
async def clear_history(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/clear")
    if user_id in chat_history:
        del chat_history[user_id]
    await message.reply(get_translation(user_id, "history_cleared"))


# Обработчик команды /settings
@dp.message(Command("settings"))
async def show_settings(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/settings")

    markup = types.InlineKeyboardMarkup()
    btn1 = types.InlineKeyboardButton(get_translation(user_id, "model_button"), callback_data="set_model")
    btn2 = types.InlineKeyboardButton(get_translation(user_id, "temp_button"), callback_data="set_temp")
    btn3 = types.InlineKeyboardButton(get_translation(user_id, "tokens_button"), callback_data="set_tokens")
    markup.add(btn1, btn2, btn3)

    await message.reply(get_translation(user_id, "select_setting"), reply_markup=markup)


# Обработчик команды /audio
@dp.message(Command("audio"))
async def generate_audio_command(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/audio")

    if message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        audio = await generate_audio(user_id, text)
        if audio:
            await message.reply_audio(audio, caption=get_translation(user_id, "audio_caption"))
        else:
            await message.reply(get_translation(user_id, "audio_error"))
    else:
        await message.reply(get_translation(user_id, "audio_instruction"))


# Обработчик команды /speech
@dp.message(Command("speech"))
async def recognize_speech_command(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/speech")

    if message.reply_to_message and message.reply_to_message.voice:
        voice_file = await bot.download_file_by_id(message.reply_to_message.voice.file_id)
        audio_file = BytesIO(voice_file)
        text = await recognize_speech(audio_file)
        await message.reply(f"{get_translation(user_id, 'speech_recognized')} {text}")
    else:
        await message.reply(get_translation(user_id, "speech_instruction"))


# Обработчик команды /image
@dp.message(Command("image"))
async def generate_image_command(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/image")

    if message.text.split(maxsplit=1)[1:]:
        prompt = message.text.split(maxsplit=1)[1]
        image_url = await generate_image(user_id, prompt)
        if image_url:
            await message.reply_photo(image_url, caption=get_translation(user_id, "image_caption"))
        else:
            await message.reply(get_translation(user_id, "image_error"))
    else:
        await message.reply(get_translation(user_id, "image_instruction"))


# Обработчик команды /video
@dp.message(Command("video"))
async def analyze_video_command(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/video")

    if message.reply_to_message and message.reply_to_message.video:
        video_file = await bot.download_file_by_id(message.reply_to_message.video.file_id)
        # Для упрощения предполагаем, что видео загружается на временный сервер
        # В реальном проекте нужно использовать облачное хранилище
        video_url = "TEMPORARY_VIDEO_URL"  # Замените на реальный URL после загрузки
        description = await analyze_video(user_id, video_url)
        await message.reply(f"{get_translation(user_id, 'video_description')} {description}")
    else:
        await message.reply(get_translation(user_id, "video_instruction"))


# Обработчик команды /weather
@dp.message(Command("weather"))
async def get_weather_command(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/weather")

    if message.text.split(maxsplit=1)[1:]:
        city = message.text.split(maxsplit=1)[1]
        weather_info = await get_weather(user_id, city)
        await message.reply(weather_info)
    else:
        await message.reply(get_translation(user_id, "weather_instruction"))


# Обработчик команды /analytics
@dp.message(Command("analytics"))
async def show_analytics(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "/analytics")

    stats = "\n".join([f"{cmd}: {count}" for cmd, count in analytics_data.items()])
    plot = create_analytics_plot()
    await message.reply(get_translation(user_id, "analytics_message").format(stats))
    await message.reply_photo(plot, caption=get_translation(user_id, "analytics_plot_caption"))


# Обработчик голосовых сообщений для команд
@dp.message(F.voice)
async def handle_voice_command(message: types.Message):
    user_id = message.from_user.id
    log_analytics(user_id, "voice_command")

    voice_file = await bot.download_file_by_id(message.voice.file_id)
    audio_file = BytesIO(voice_file)
    text = await recognize_speech(audio_file)

    commands = {
        "start": send_welcome,
        "clear": clear_history,
        "settings": show_settings,
        "audio": generate_audio_command,
        "speech": recognize_speech_command,
        "image": generate_image_command,
        "video": analyze_video_command,
        "weather": get_weather_command,
        "analytics": show_analytics
    }

    for cmd, handler in commands.items():
        if cmd in text.lower():
            await handler(message)
            return
    await message.reply(get_translation(user_id, "unknown_command"))


# Обработчик текстовых сообщений
@dp.message(F.text)
async def handle_message(message: types.Message):
    user_id = message.from_user.id
    user_text = message.text

    log_analytics(user_id, "text_message")

    translations = {
        get_translation(user_id, "info_button"): lambda: message.reply(get_translation(user_id, "info_message")),
        get_translation(user_id, "settings_button"): show_settings,
        get_translation(user_id, "history_button"): lambda: message.reply(
            "\n".join([f"{msg['role']}: {msg['content']}" for msg in chat_history.get(user_id, [])])
            if user_id in chat_history and chat_history[user_id]
            else get_translation(user_id, "history_empty")
        ),
        get_translation(user_id, "language_button"): lambda: message.reply(
            get_translation(user_id, "language_prompt"),
            reply_markup=types.InlineKeyboardMarkup().add(
                *[types.InlineKeyboardButton(lang, callback_data=f"lang_{lang}") for lang in TRANSLATIONS.keys()]
            )
        )
    }

    if user_text in translations:
        await translations[user_text]()
    else:
        response = await get_openai_response(user_id, user_text)
        await message.reply(response)


# Обработчик callback-запросов
@dp.callback_query()
async def callback_handler(call: types.CallbackQuery):
    user_id = call.from_user.id
    settings = get_user_settings(user_id)

    if call.data.startswith("lang_"):
        lang = call.data.split("_")[1]
        settings["language"] = lang
        save_user_settings(user_id, settings)
        await call.message.reply(get_translation(user_id, "language_updated"))
        await call.answer()
    elif call.data == "set_model":
        await call.message.reply(get_translation(user_id, "model_prompt"))
        await call.answer()
    elif call.data == "set_temp":
        await call.message.reply(get_translation(user_id, "temp_prompt"))
        await call.answer()
    elif call.data == "set_tokens":
        await call.message.reply(get_translation(user_id, "tokens_prompt"))
        await call.answer()


# Обработчик ввода настроек
@dp.message(F.text & F.reply_to_message)
async def handle_settings_input(message: types.Message):
    user_id = message.from_user.id
    settings = get_user_settings(user_id)

    reply_text = message.reply_to_message.text
    if get_translation(user_id, "model_prompt") in reply_text:
        settings["model"] = message.text
        save_user_settings(user_id, settings)
        await message.reply(get_translation(user_id, "model_updated"))
    elif get_translation(user_id, "temp_prompt") in reply_text:
        try:
            settings["temp"] = float(message.text)
            save_user_settings(user_id, settings)
            await message.reply(get_translation(user_id, "temp_updated"))
        except ValueError:
            await message.reply(get_translation(user_id, "temp_error"))
    elif get_translation(user_id, "tokens_prompt") in reply_text:
        try:
            settings["max_tokens"] = int(message.text)
            save_user_settings(user_id, settings)
            await message.reply(get_translation(user_id, "tokens_updated"))
        except ValueError:
            await message.reply(get_translation(user_id, "tokens_error"))


# Запуск бота
async def main():
    logger.info("Бот запущен...")
    try:
        await dp.start_polling(bot)
    except Exception as e:
        logger.error(f"Ошибка при запуске бота: {str(e)}")


if __name__ == "__main__":
    asyncio.run(main())